'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Play, 
  Palette, 
  Radio, 
  Video, 
  Users, 
  Mail, 
  Phone, 
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Youtube,
  Linkedin,
  ExternalLink,
  Clock,
  TrendingUp,
  Award,
  Target
} from 'lucide-react'

export default function Home() {
  const [activeService, setActiveService] = useState<string | null>(null)

  const services = [
    {
      id: 'live-streams',
      title: 'Live Streams',
      description: 'Real-time broadcasting of university events, lectures, and special programming',
      icon: Play,
      features: ['HD Quality Streaming', 'Multi-platform Support', 'Interactive Chat', 'On-demand Playback'],
      color: 'bg-red-500'
    },
    {
      id: 'graphic-design',
      title: 'Graphic Designing',
      description: 'Professional design services for branding, marketing, and digital content',
      icon: Palette,
      features: ['Brand Identity', 'Digital Graphics', 'Print Design', 'Motion Graphics'],
      color: 'bg-purple-500'
    },
    {
      id: 'news-broadcast',
      title: 'Live News Broadcast',
      description: 'Up-to-date news coverage and current affairs programming',
      icon: Radio,
      features: ['Daily News Updates', 'Investigative Journalism', 'Student Reporting', 'Community News'],
      color: 'bg-blue-500'
    },
    {
      id: 'content-creation',
      title: 'Content Creation',
      description: 'Creative content production for various platforms and purposes',
      icon: Video,
      features: ['Video Production', 'Podcast Creation', 'Documentary Making', 'Social Media Content'],
      color: 'bg-green-500'
    }
  ]

  const executiveMembers = [
    {
      name: 'Dr. Sarah Mwansa',
      position: 'Director of Digital Media',
      bio: 'Leading digital media innovation with over 15 years of experience in broadcast journalism and digital content strategy.',
      image: '/api/placeholder/150/150'
    },
    {
      name: 'James Banda',
      position: 'Head of Production',
      bio: 'Expert in video production and live broadcasting, passionate about mentoring the next generation of media professionals.',
      image: '/api/placeholder/150/150'
    },
    {
      name: 'Esther Phiri',
      position: 'Technical Director',
      bio: 'Specializing in broadcast technology and digital infrastructure, ensuring seamless delivery of all media content.',
      image: '/api/placeholder/150/150'
    },
    {
      name: 'Michael Mulenga',
      position: 'Content Manager',
      bio: 'Creative content strategist with expertise in digital storytelling and audience engagement across multiple platforms.',
      image: '/api/placeholder/150/150'
    }
  ]

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, url: 'https://facebook.com/dmhtv' },
    { name: 'Twitter', icon: Twitter, url: 'https://twitter.com/dmhtv' },
    { name: 'Instagram', icon: Instagram, url: 'https://instagram.com/dmhtv' },
    { name: 'YouTube', icon: Youtube, url: 'https://youtube.com/dmhtv' },
    { name: 'LinkedIn', icon: Linkedin, url: 'https://linkedin.com/company/dmhtv' }
  ]

  const stats = [
    { label: 'Students Trained', value: '500+', icon: Users },
    { label: 'Live Broadcasts', value: '200+', icon: Radio },
    { label: 'Content Pieces', value: '1000+', icon: Video },
    { label: 'Years of Excellence', value: '10+', icon: Award }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <img
                src="/dmh-logo.png"
                alt="DMH-TV Logo"
                className="h-8 w-8 rounded"
              />
              <span className="text-xl font-bold">DMH-TV</span>
            </div>
            <Badge variant="secondary" className="hidden sm:inline-flex">
              Digital Media Hub
            </Badge>
          </div>
          
          <nav className="hidden md:flex items-center space-x-6">
            <Button variant="ghost" onClick={() => window.scrollTo({ top: 400, behavior: 'smooth' })}>
              Services
            </Button>
            <Button variant="ghost" onClick={() => window.scrollTo({ top: 1200, behavior: 'smooth' })}>
              About
            </Button>
            <Button variant="ghost" onClick={() => window.scrollTo({ top: 2000, behavior: 'smooth' })}>
              Portfolio
            </Button>
            <Button variant="ghost" onClick={() => window.scrollTo({ top: 2800, behavior: 'smooth' })}>
              Team
            </Button>
            <Button variant="ghost" onClick={() => window.scrollTo({ top: 3600, behavior: 'smooth' })}>
              Contact
            </Button>
          </nav>

          <div className="flex items-center space-x-2">
            {socialLinks.map((social) => (
              <Button key={social.name} variant="ghost" size="sm" asChild>
                <a href={social.url} target="_blank" rel="noopener noreferrer">
                  <social.icon className="h-4 w-4" />
                </a>
              </Button>
            ))}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
        <div className="container mx-auto">
          <div className="mb-6">
            <Badge variant="outline" className="mb-4">
              University of Zambia
            </Badge>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-red-600 to-purple-600 bg-clip-text text-transparent">
            DMH-TV
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-4">
            Digital Media Hub
          </p>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
            Empowering University of Zambia media and communication students with hands-on training in production, 
            broadcasting, and digital media skills. Your platform for creative expression and professional development.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-red-500 to-purple-500 hover:from-red-600 hover:to-purple-600">
              <Play className="mr-2 h-4 w-4" />
              Watch Live
            </Button>
            <Button size="lg" variant="outline">
              <ExternalLink className="mr-2 h-4 w-4" />
              Explore Services
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-background">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <Card key={stat.label} className="text-center">
                <CardContent className="pt-6">
                  <stat.icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 bg-slate-50 dark:bg-slate-900">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive media services designed to train students and serve the university community
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {services.map((service) => (
              <Card 
                key={service.id} 
                className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                  activeService === service.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setActiveService(activeService === service.id ? null : service.id)}
              >
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-lg ${service.color}`}>
                      <service.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{service.title}</CardTitle>
                      <CardDescription>{service.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                {activeService === service.id && (
                  <CardContent>
                    <Separator className="mb-4" />
                    <h4 className="font-semibold mb-2">Key Features:</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, index) => (
                        <li key={index} className="flex items-center space-x-2">
                          <div className="h-2 w-2 rounded-full bg-primary"></div>
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-background">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About DMH-TV</h2>
            <Badge variant="secondary" className="mb-4">
              Digital Media Hub - University of Zambia
            </Badge>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <span>Our Mission</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To provide practical training and hands-on experience in media production, 
                  broadcasting, and digital content creation for University of Zambia students, 
                  preparing them for successful careers in the media industry.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <span>Our Vision</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To become the leading digital media training hub in Africa, producing innovative 
                  media professionals who shape the future of broadcasting and digital content.
                </p>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Training & Development</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                DMH-TV serves as a practical training ground where media and communication students 
                can apply theoretical knowledge in real-world scenarios. Our comprehensive training 
                programs cover:
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {[
                  'Video Production & Editing',
                  'Live Broadcasting Techniques',
                  'Graphic Design & Animation',
                  'Journalism & News Reporting',
                  'Social Media Management',
                  'Audio Production & Podcasting'
                ].map((skill) => (
                  <div key={skill} className="flex items-center space-x-2">
                    <div className="h-2 w-2 rounded-full bg-green-500"></div>
                    <span className="text-sm">{skill}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 px-4 bg-slate-50 dark:bg-slate-900">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Portfolio</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our latest projects and creative works from talented DMH-TV students
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'UNZA Graduation Ceremony 2024',
                description: 'Complete live coverage of the graduation ceremony with multi-camera setup',
                type: 'Live Stream',
                thumbnail: '/api/placeholder/400/225',
                category: 'Events',
                featured: true
              },
              {
                title: 'DMH-TV Brand Identity',
                description: 'Complete brand identity package including logo design and guidelines',
                type: 'Graphic Design',
                thumbnail: '/api/placeholder/400/225',
                category: 'Branding',
                featured: false
              },
              {
                title: 'Weekly News Digest - Episode 15',
                description: 'Latest news and updates from around the university community',
                type: 'News Broadcast',
                thumbnail: '/api/placeholder/400/225',
                category: 'News',
                featured: false
              },
              {
                title: 'Student Documentary: Campus Life',
                description: 'A documentary exploring daily life and experiences at UNZA',
                type: 'Content Creation',
                thumbnail: '/api/placeholder/400/225',
                category: 'Documentary',
                featured: true
              },
              {
                title: 'Sports Coverage: UNZA vs CBU',
                description: 'Live sports broadcasting with commentary and analysis',
                type: 'Live Stream',
                thumbnail: '/api/placeholder/400/225',
                category: 'Sports',
                featured: false
              },
              {
                title: 'Social Media Campaign Design',
                description: 'Creative graphics for university awareness campaign',
                type: 'Graphic Design',
                thumbnail: '/api/placeholder/400/225',
                category: 'Marketing',
                featured: false
              }
            ].map((item, index) => (
              <Card key={index} className="overflow-hidden group cursor-pointer hover:shadow-lg transition-all duration-300">
                <div className="relative">
                  <div className="aspect-video bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-800 flex items-center justify-center">
                    <Video className="h-12 w-12 text-slate-500" />
                  </div>
                  {item.featured && (
                    <Badge className="absolute top-2 right-2 bg-yellow-500 hover:bg-yellow-600">
                      Featured
                    </Badge>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button variant="secondary" size="sm">
                      <Play className="mr-2 h-4 w-4" />
                      View Project
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline">{item.category}</Badge>
                    <Badge variant="secondary">{item.type}</Badge>
                  </div>
                  <h3 className="font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button size="lg" variant="outline">
              View All Projects
              <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Executive Team Section */}
      <section id="team" className="py-20 px-4 bg-slate-50 dark:bg-slate-900">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Executive Team</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Meet the dedicated professionals leading DMH-TV and shaping the future of digital media education
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {executiveMembers.map((member) => (
              <Card key={member.name} className="text-center">
                <CardHeader>
                  <div className="mx-auto mb-4 h-24 w-24 rounded-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center">
                    <Users className="h-12 w-12 text-white" />
                  </div>
                  <CardTitle className="text-lg">{member.name}</CardTitle>
                  <CardDescription>{member.position}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Partnership Section */}
      <section id="contact" className="py-20 px-4 bg-background">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <p className="text-lg text-muted-foreground">
              Partner with us or learn more about our services
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="h-5 w-5 text-primary" />
                  <span>Contact Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>info@dmhtv.unza.zm</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>+260 211 123456</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>University of Zambia, Great East Road Campus</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Mon-Fri: 8:00 AM - 6:00 PM</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Partnership Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  We welcome partnerships with organizations interested in:
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span>Sponsorship of student projects</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span>Advertising on our platforms</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span>Internship programs</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span>Equipment and technology support</span>
                  </li>
                </ul>
                <Button className="w-full mt-4">
                  Become a Partner
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img
                  src="/dmh-logo.png"
                  alt="DMH-TV Logo"
                  className="h-8 w-8 rounded"
                />
                <span className="text-xl font-bold">DMH-TV</span>
              </div>
              <p className="text-sm text-slate-400">
                Digital Media Hub - University of Zambia
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Live Streams</Button></li>
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Services</Button></li>
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Portfolio</Button></li>
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Training</Button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Student Portal</Button></li>
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Equipment Booking</Button></li>
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Schedule</Button></li>
                <li><Button variant="link" className="text-slate-400 p-0 h-auto">Guidelines</Button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-2">
                {socialLinks.map((social) => (
                  <Button key={social.name} variant="outline" size="sm" asChild>
                    <a href={social.url} target="_blank" rel="noopener noreferrer" className="text-slate-400 border-slate-700 hover:text-white">
                      <social.icon className="h-4 w-4" />
                    </a>
                  </Button>
                ))}
              </div>
            </div>
          </div>
          
          <Separator className="my-8 bg-slate-700" />
          
          <div className="text-center text-sm text-slate-400">
            <p>&copy; 2024 DMH-TV - Digital Media Hub, University of Zambia. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}